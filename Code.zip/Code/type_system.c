#include "type_system.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include "semantic.h"

/// ==================== 安全字符串拷贝 ====================
static char* copyString(const char *s) {
    if (!s) return NULL;
    char *p = (char *)malloc(strlen(s) + 1);
    if (p) strcpy(p, s);
    return p;
}

/// ==================== 类型构造 ====================

Type makeBasicType(int basicKind) {
    Type t = (Type)malloc(sizeof(*t));
    t->kind = BASIC;
    t->u.basic = (basicKind == 0) ? TYPE_INT : TYPE_FLOAT;
    return t;
}

Type makeArrayType(Type elem, int size) {
    Type t = (Type)malloc(sizeof(*t));
    t->kind = ARRAY;
    t->u.array.elem = elem;
    t->u.array.size = size;
    return t;
}

Type makeStructType(const char *name) {
    Type t = (Type)malloc(sizeof(*t));
    t->kind = STRUCTURE;
    t->u.structure.name = copyString(name);
    t->u.structure.fields = NULL;
    return t;
}

Type makeFunctionType(Type retType, FieldList params) {
    Type t = (Type)malloc(sizeof(*t));
    t->kind = FUNCTION;
    t->u.function.retType = retType;
    t->u.function.params = params;
    return t;
}

/// ==================== 字段操作 ====================

FieldList makeField(const char *name, Type type) {
    FieldList f = (FieldList)malloc(sizeof(*f));
    f->name = copyString(name);
    f->type = type;
    f->tail = NULL;
    return f;
}

void addField(Type structType, const char *fieldName, Type fieldType) {
    if (!structType || structType->kind != STRUCTURE) return;
    FieldList f = makeField(fieldName, fieldType);
    f->tail = structType->u.structure.fields;
    structType->u.structure.fields = f;
}

FieldList findField(Type structType, const char *fieldName) {
    if (!structType || structType->kind != STRUCTURE) return NULL;
    FieldList f = structType->u.structure.fields;
    while (f) {
        if (strcmp(f->name, fieldName) == 0)
            return f;
        f = f->tail;
    }
    return NULL;
}

/// ==================== 类型比较 ====================

bool typeEqual(Type t1, Type t2) {
    if (!t1 || !t2) return false;
    if (t1->kind != t2->kind) return false;
    switch (t1->kind) {
        case BASIC:
            return t1->u.basic == t2->u.basic;
        case ARRAY:
            return typeEqual(t1->u.array.elem, t2->u.array.elem);
        case STRUCTURE:
            if (t1->u.structure.name && t2->u.structure.name)
                return strcmp(t1->u.structure.name, t2->u.structure.name) == 0;
            return false;
        default:
            return false;
    }
}

bool isInt(Type t) { return t && t->kind == BASIC && t->u.basic == TYPE_INT; }
bool isFloat(Type t) { return t && t->kind == BASIC && t->u.basic == TYPE_FLOAT; }

bool checkFuncArgs(Type funcType, FieldList args) {
    if (!funcType || funcType->kind != FUNCTION) return false;
    FieldList p1 = funcType->u.function.params, p2 = args;
    while (p1 && p2) {
        if (!typeEqual(p1->type, p2->type))
            return false;
        p1 = p1->tail;
        p2 = p2->tail;
    }
    return !p1 && !p2;
}

/// ==================== Stub函数（供semantic.c使用） ====================

bool isLValue(void *exp) {
    /* 仅当节点是 ID 或 Exp LB Exp 或 Exp DOT ID 时视为左值 */
    Node *n = (Node *)exp;
    if (!n) return false;
    if (strcmp(n->type, "Exp") == 0 && n->child_count >= 1) {
        Node *c = n->children[0];
        if (c && strcmp(c->type, "ID") == 0 && n->child_count == 1) return true;
        if (n->child_count == 4 && strcmp(n->children[1]->type, "LB") == 0) return true;
        if (n->child_count == 3 && strcmp(n->children[1]->type, "DOT") == 0) return true;
    }
    return false;
}
Type getType(Node *specifier) {
    if (!specifier) return NULL;
    if (specifier->child_count == 0) return NULL;

    Node *first = specifier->children[0];

    if (strcmp(first->type, "TYPE") == 0) {
        if (first->value && strcmp(first->value, "int") == 0)
            return makeBasicType(0);
        else
            return makeBasicType(1); /* 默认 float 或其它映射为 float */
    }

    if (strcmp(first->type, "StructSpecifier") == 0) {
        Node *ss = first;
        /* STRUCT ID  -> reference to struct */
        if (ss->child_count >= 2 && strcmp(ss->children[1]->type, "ID") == 0) {
            char *name = ss->children[1]->value;
            /* 返回一个结构体类型，name 填上。是否已定义由外层检查 (findStruct) */
            return makeStructType(name);
        }

        /* STRUCT OptTag LC DefList RC  -> definition with fields */
        /* OptTag may be absent; child layout: 0:STRUCT, 1:OptTag (maybe ID or NULL), 2:LC, 3:DefList, 4:RC
           but your grammar had STRUCT OptTag LC DefList RC (5 children).
           To be robust, search for DefList child. */
        Node *defListNode = NULL;
        char *maybeName = NULL;
        for (int i = 0; i < ss->child_count; ++i) {
            if (ss->children[i] && strcmp(ss->children[i]->type, "DefList") == 0) {
                defListNode = ss->children[i];
                break;
            }
            if (ss->children[i] && strcmp(ss->children[i]->type, "OptTag") == 0) {
                if (ss->children[i]->child_count == 1 && ss->children[i]->children[0])
                    maybeName = ss->children[i]->children[0]->value;
            }
        }

        Type structType = makeStructType(maybeName);
        if (defListNode) {
            /* defList: sequence of Def nodes */
            for (int i = 0; i < defListNode->child_count; ++i) {
                Node *def = defListNode->children[i];
                if (!def || def->child_count < 2) continue;
                Node *specifierNode = def->children[0]; // Specifier
                Node *decListNode = def->children[1];  // DecList
                Type fieldType = getType(specifierNode);
                if (!decListNode) continue;
                for (int j = 0; j < decListNode->child_count; ++j) {
                    Node *dec = decListNode->children[j]; // Dec
                    if (!dec || dec->child_count == 0) continue;
                    Node *varDec = dec->children[0]; // VarDec
                    /* VarDec can be ID or VarDec LB INT RB */
                    if (varDec && varDec->child_count >= 1 && varDec->children[0]) {
                        char *fieldName = varDec->children[0]->value;
                        if (fieldName) {
                            addField(structType, fieldName, fieldType);
                        }
                    }
                }
            }
        }
        return structType;
    }

    return NULL;
}
FieldList getArgs(Node *argsNode) {
    if (!argsNode) return NULL;

    FieldList head = NULL;
    FieldList tail = NULL;

    Node *cur = argsNode;
    while (cur) {
        /* cur 类型可以是 "Args" 节点，child_count 1 或 3 */
        Node *first = cur->children[0];
        if (!first) break;
        /* first 应为 Exp（根据你的 grammar） */
        Type t = checkExpression(first);
        FieldList f = makeField(NULL, t);
        if (!head) { head = f; tail = f; }
        else { tail->tail = f; tail = f; }

        if (cur->child_count == 3) {
            /* 架构为 Exp COMMA Args, 下一项在 cur->children[2] */
            cur = cur->children[2];
        } else break;
    }
    return head;
}
Type buildFunctionType(Node *funDec, Type returnType) {
    FieldList params = NULL;
    FieldList tail = NULL;

    if (!funDec) return makeFunctionType(returnType, NULL);

    /* 如果 funDec->child_count == 4 并且 children[2] 是 VarList */
    if (funDec->child_count >= 3 && funDec->children[1] && strcmp(funDec->children[1]->type, "LP") == 0) {
        if (funDec->child_count == 4 && funDec->children[2]) {
            Node *varList = funDec->children[2];
            Node *cur = varList;
            while (cur) {
                /* ParamDec: Specifier VarDec */
                Node *paramDec = cur->children[0];
                if (paramDec && paramDec->child_count >= 2) {
                    Node *specifierNode = paramDec->children[0];
                    Node *varDecNode = paramDec->children[1];
                    Type pType = getType(specifierNode);
                    /* varDecNode->children[0] is ID or nested VarDec */
                    char *pname = NULL;
                    if (varDecNode && varDecNode->child_count >= 1 && varDecNode->children[0]) {
                        pname = varDecNode->children[0]->value;
                    }
                    FieldList f = makeField(pname, pType);
                    if (!params) { params = f; tail = f; }
                    else { tail->tail = f; tail = f; }
                }
                if (cur->child_count == 3) cur = cur->children[2];
                else break;
            }
        }
    }
    return makeFunctionType(returnType, params);
}

