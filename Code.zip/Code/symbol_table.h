#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include "type_system.h"

/// ==================== 符号表定义 ====================

typedef struct Symbol {
    char *name;
    Type type;
    int lineNo;
    struct Symbol *next;
} Symbol;

void initSymbolTable();
void enterScope();
void exitScope();

Symbol *findSymbol(const char *name);
void insertSymbol(Symbol *sym);
Symbol *createVariableSymbol(const char *name, Type type, int lineNo);
Symbol *createFunctionSymbol(const char *name, Type type, int lineNo);

// 结构体表
Type findStruct(const char *name);
void insertStruct(const char *name, Type type);

// 函数参数插入
void insertFuncParams(void *funDecNode, Type funcType);

#endif
