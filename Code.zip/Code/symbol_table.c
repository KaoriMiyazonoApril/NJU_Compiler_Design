#include "symbol_table.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

/// ==================== 安全字符串拷贝 ====================
static char* copyString(const char *s) {
    if (!s) return NULL;
    char *p = (char *)malloc(strlen(s) + 1);
    if (p) strcpy(p, s);
    return p;
}

/// ==================== 基础表结构 ====================
#define MAX_SCOPE 64
static Symbol *symbolTable[MAX_SCOPE];
static int currentScope = 0;

typedef struct StructEntry {
    char *name;
    Type type;
    struct StructEntry *next;
} StructEntry;

static StructEntry *structTable = NULL;

/// ==================== 符号表操作 ====================

void initSymbolTable() {
    memset(symbolTable, 0, sizeof(symbolTable));
    currentScope = 0;
    structTable = NULL;
}

void enterScope() {
    if (currentScope + 1 < MAX_SCOPE)
        currentScope++;
}

void exitScope() {
    Symbol *p = symbolTable[currentScope];
    while (p) {
        Symbol *tmp = p;
        p = p->next;
        free(tmp->name);
        free(tmp);
    }
    symbolTable[currentScope] = NULL;
    if (currentScope > 0)
        currentScope--;
}

Symbol *findSymbol(const char *name) {
    for (int i = currentScope; i >= 0; i--) {
        Symbol *p = symbolTable[i];
        while (p) {
            if (strcmp(p->name, name) == 0)
                return p;
            p = p->next;
        }
    }
    return NULL;
}

void insertSymbol(Symbol *sym) {
    sym->next = symbolTable[currentScope];
    symbolTable[currentScope] = sym;
}

Symbol *createVariableSymbol(const char *name, Type type, int lineNo) {
    Symbol *sym = (Symbol *)malloc(sizeof(Symbol));
    sym->name = copyString(name);
    sym->type = type;
    sym->lineNo = lineNo;
    sym->next = NULL;
    return sym;
}

Symbol *createFunctionSymbol(const char *name, Type type, int lineNo) {
    return createVariableSymbol(name, type, lineNo);
}

/// ==================== 结构体表操作 ====================

Type findStruct(const char *name) {
    StructEntry *p = structTable;
    while (p) {
        if (strcmp(p->name, name) == 0)
            return p->type;
        p = p->next;
    }
    return NULL;
}

void insertStruct(const char *name, Type type) {
    StructEntry *entry = (StructEntry *)malloc(sizeof(StructEntry));
    entry->name = copyString(name);
    entry->type = type;
    entry->next = structTable;
    structTable = entry;
}

/// ==================== 函数参数插入 ====================

void insertFuncParams(void *funDecNode, Type funcType) {
    FieldList f = funcType->u.function.params;
    while (f) {
        insertSymbol(createVariableSymbol(f->name, f->type, 0));
        f = f->tail;
    }
}
