#ifndef TYPE_SYSTEM_H
#define TYPE_SYSTEM_H

#include <stdbool.h>
#include "Node/Node.h"

/// ==================== 类型系统定义 ====================

typedef enum { BASIC, ARRAY, STRUCTURE, FUNCTION } Kind;

/// 基本类型
typedef enum { TYPE_INT, TYPE_FLOAT } BasicKind;

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;

struct Type_ {
    Kind kind;
    union {
        BasicKind basic; // BASIC
        struct {         // ARRAY
            Type elem;
            int size;
        } array;
        struct {         // STRUCTURE
            char *name;       // 结构体名，可为空
            FieldList fields; // 成员字段
        } structure;
        struct { // FUNCTION
            Type retType;
            FieldList params;
        } function;
    } u;
};

struct FieldList_ {
    char *name;
    Type type;
    FieldList tail;
};

/// ==================== 类型操作函数声明 ====================

// 创建类型
Type makeBasicType(int basicKind); // 0:int, 1:float
Type makeArrayType(Type elem, int size);
Type makeStructType(const char *name);
Type makeFunctionType(Type retType, FieldList params);

// 字段操作
FieldList makeField(const char *name, Type type);
void addField(Type structType, const char *fieldName, Type fieldType);
FieldList findField(Type structType, const char *fieldName);

// 类型比较
bool typeEqual(Type t1, Type t2);
bool isInt(Type t);
bool isFloat(Type t);

// 函数参数检查
bool checkFuncArgs(Type funcType, FieldList args);

// 其他辅助函数
bool isLValue(void *exp); // stub, 语义分析时定义
Type getType(Node *specifierNode); // stub, 从 Specifier 节点中解析类型
FieldList getArgs(Node *argsNode);
Type buildFunctionType(Node *funDecNode, Type returnType);

#endif
