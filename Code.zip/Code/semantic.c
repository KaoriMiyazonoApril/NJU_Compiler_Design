#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Node/Node.h"
#include "symbol_table.h"
#include "type_system.h"
#include "semantic.h"

/// ==================== 错误输出接口 ====================
void semanticError(int type, int line, const char *msg) {
    printf("Error type %d at Line %d: %s.\n", type, line, msg);
}

/// ==================== 主入口函数 ====================
void semanticAnalysis(Node *root) {
    if (root == NULL) return;
    traverseProgram(root);
}

/// =====================================================
///                     Program
/// =====================================================
void traverseProgram(Node *node) {
    if (node == NULL || node->child_count == 0) return;
    traverseExtDefList(node->children[0]);
}

/// =====================================================
///                     ExtDefList
/// =====================================================
void traverseExtDefList(Node *node) {
    if (node == NULL || node->child_count == 0) return;
    traverseExtDef(node->children[0]);
    if (node->child_count == 2)
        traverseExtDefList(node->children[1]);
}

/// =====================================================
///                     ExtDef
/// =====================================================
void traverseExtDef(Node *node) {
    if (node == NULL || node->child_count == 0) return;

    Node *specifier = node->children[0];
    Type type = getType(specifier); // 获取类型

    // Specifier ExtDecList SEMI
    if (node->child_count == 3 && strcmp(node->children[1]->type, "ExtDecList") == 0) {
        traverseExtDecList(node->children[1], type);
    }
        // Specifier FunDec CompSt
    else if (node->child_count == 3 && strcmp(node->children[1]->type, "FunDec") == 0) {
        handleFunctionDef(node->children[1], type, node->children[2]);
    }
        // StructDef
    else if (strcmp(specifier->type, "StructSpecifier") == 0) {
        handleStructDef(specifier);
    }
}

/// =====================================================
///                     ExtDecList
/// =====================================================
void traverseExtDecList(Node *node, Type type) {
    if (node == NULL || node->child_count == 0) return;

    Node *varDec = node->children[0];
    char *varName = varDec->children[0]->value;

    if (findSymbol(varName)) {
        semanticError(3, varDec->lineNo, "Redefined variable");
    } else {
        Type finalType = type;
        if (type->kind == STRUCTURE)
            finalType = checkStructVariable(varDec, type); // 检查结构体是否定义
        insertSymbol(createVariableSymbol(varName, finalType, varDec->lineNo));
    }

    if (node->child_count == 3)
        traverseExtDecList(node->children[2], type);
}

/// =====================================================
///                     函数定义
/// =====================================================
void handleFunctionDef(Node *funDec, Type returnType, Node *compSt) {
    char *funcName = funDec->children[0]->value;

    if (findSymbol(funcName)) {
        semanticError(4, funDec->lineNo, "Redefined function");
        return;
    }

    Type funcType = buildFunctionType(funDec, returnType);
    insertSymbol(createFunctionSymbol(funcName, funcType, funDec->lineNo));

    enterScope();
    insertFuncParams(funDec, funcType);
    traverseCompSt(compSt, returnType);
    exitScope();
}

/// =====================================================
///                     复合语句 CompSt
/// =====================================================
void traverseCompSt(Node *node, Type returnType) {
    if (node->child_count < 4) return;
    Node *defList = node->children[1];
    Node *stmtList = node->children[2];
    traverseDefList(defList);
    traverseStmtList(stmtList, returnType);
}

/// =====================================================
///                     定义列表 DefList
/// =====================================================
void traverseDefList(Node *node) {
    if (node == NULL || node->child_count == 0) return;
    traverseDef(node->children[0]);
    if (node->child_count == 2)
        traverseDefList(node->children[1]);
}

/// =====================================================
///                     单个定义 Def
/// =====================================================
void traverseDef(Node *node) {
    if (node == NULL || node->child_count == 0) return;
    Type type = getType(node->children[0]);
    traverseDecList(node->children[1], type);
}

/// =====================================================
///                     DecList
/// =====================================================
void traverseDecList(Node *node, Type type) {
    if (node == NULL || node->child_count == 0) return;

    Node *dec = node->children[0];
    Node *varDec = dec->children[0];
    char *varName = varDec->children[0]->value;

    if (findSymbol(varName)) {
        semanticError(3, varDec->lineNo, "Redefined variable");
    } else {
        Type finalType = type;
        if (type->kind == STRUCTURE)
            finalType = checkStructVariable(varDec, type);
        insertSymbol(createVariableSymbol(varName, finalType, varDec->lineNo));
    }

    if (dec->child_count == 3) {
        Type left = type;
        Type right = checkExpression(dec->children[2]);
        if (!typeEqual(left, right))
            semanticError(5, varDec->lineNo, "Type mismatched for assignment");
    }

    if (node->child_count == 3)
        traverseDecList(node->children[2], type);
}

/// =====================================================
///                     StmtList
/// =====================================================
void traverseStmtList(Node *node, Type returnType) {
    if (node == NULL || node->child_count == 0) return;
    traverseStmt(node->children[0], returnType);
    if (node->child_count == 2)
        traverseStmtList(node->children[1], returnType);
}

/// =====================================================
///                     单条语句 Stmt
/// =====================================================
void traverseStmt(Node *node, Type returnType) {
    if (node == NULL || node->child_count == 0) return;
    Node *first = node->children[0];

    if (strcmp(first->type, "Exp") == 0) {
        checkExpression(first);
    } else if (strcmp(first->type, "RETURN") == 0) {
        Type retType = checkExpression(node->children[1]);
        if (!typeEqual(retType, returnType))
            semanticError(8, first->lineNo, "Type mismatched for return");
    } else if (strcmp(first->type, "IF") == 0) {
        checkExpression(node->children[2]);
        traverseStmt(node->children[4], returnType);
        if (node->child_count == 7)
            traverseStmt(node->children[6], returnType);
    } else if (strcmp(first->type, "WHILE") == 0) {
        checkExpression(node->children[2]);
        traverseStmt(node->children[4], returnType);
    } else if (strcmp(first->type, "CompSt") == 0) {
        traverseCompSt(first, returnType);
    }
}

/// =====================================================
///                     表达式 Exp
/// =====================================================
Type checkExpression(Node *exp) {
    if (!exp || exp->child_count == 0) return NULL;
    Node *c = exp->children[0];

    // 单个 ID
    if (strcmp(c->type, "ID") == 0 && exp->child_count == 1) {
        Symbol *sym = findSymbol(c->value);
        if (!sym) {
            semanticError(1, c->lineNo, "Undefined variable");
            return NULL;
        }
        return sym->type;
    }

    // 常量
    if (strcmp(c->type, "INT") == 0) return makeBasicType(0);
    if (strcmp(c->type, "FLOAT") == 0) return makeBasicType(1);

    // 赋值表达式
    if (exp->child_count == 3 && strcmp(exp->children[1]->type, "ASSIGNOP") == 0) {
        Type t1 = checkExpression(exp->children[0]);
        Type t2 = checkExpression(exp->children[2]);
        if (!isLValue(exp->children[0]))
            semanticError(6, exp->lineNo, "Left-hand side must be variable");
        else if (t1 != NULL && t2 != NULL&&!typeEqual(t1, t2))
            semanticError(5, exp->lineNo, "Type mismatched for assignment");
        return t1;
    }

    // 算术运算
    if (exp->child_count == 3 &&
        (strcmp(exp->children[1]->type, "PLUS") == 0 ||
         strcmp(exp->children[1]->type, "MINUS") == 0 ||
         strcmp(exp->children[1]->type, "STAR") == 0 ||
         strcmp(exp->children[1]->type, "DIV") == 0)) {
        Type t1 = checkExpression(exp->children[0]);
        Type t2 = checkExpression(exp->children[2]);
        if (!typeEqual(t1, t2) || !(isInt(t1) || isFloat(t1)))
            semanticError(7, exp->lineNo, "Type mismatched for operands");
        return t1;
    }

    // 函数调用
    if (exp->child_count >= 3 && strcmp(c->type, "ID") == 0 && strcmp(exp->children[1]->type, "LP") == 0) {
        Symbol *sym = findSymbol(c->value);
        if (!sym) {
            semanticError(2, c->lineNo, "Undefined function");
            return NULL;
        }
        if (sym->type->kind != FUNCTION) {
            semanticError(11, c->lineNo, "Is not a function");
            return NULL;
        }
        FieldList args = NULL;
        if (exp->child_count == 4)
            args = getArgs(exp->children[2]);
        if (!checkFuncArgs(sym->type, args))
            semanticError(9, c->lineNo, "Function arguments mismatch");
        return sym->type->u.function.retType;
    }

    // 数组访问
    if (exp->child_count == 4 && strcmp(exp->children[1]->type, "LB") == 0) {
        Type arrType = checkExpression(exp->children[0]);
        Type idxType = checkExpression(exp->children[2]);
        if (!arrType || arrType->kind != ARRAY)
            semanticError(10, exp->lineNo, "Not an array");
        else if (!isInt(idxType))
            semanticError(12, exp->lineNo, "Array index must be int");
        return arrType ? arrType->u.array.elem : NULL;
    }

    // 结构体成员访问
    if (exp->child_count == 3 && strcmp(exp->children[1]->type, "DOT") == 0) {
        Type t = checkExpression(exp->children[0]);
        if (!t || t->kind != STRUCTURE) {
            semanticError(13, exp->lineNo, "Illegal use of '.'");
            return NULL;
        }
        FieldList f = findField(t, exp->children[2]->value);
        if (!f)
            semanticError(14, exp->lineNo, "Non-existent field");
        else
            return f->type;
    }

    return NULL;
}

/// =====================================================
///                     结构体处理函数
/// =====================================================
Type handleStructDef(Node *node) {
    if (!node) return NULL;
    char *structName = NULL;
    int lineNo = node->lineNo;
    if (node->child_count >= 2 && strcmp(node->children[1]->type, "ID") == 0) {
        structName = node->children[1]->value;
        if (findStruct(structName)) {
            semanticError(16, node->children[1]->lineNo, "Duplicated name");
        }
    }

    Type structType = makeStructType(structName);

    if (node->child_count == 4 && strcmp(node->children[2]->type, "DefList") == 0) {
        Node *defList = node->children[2];
        for (int i = 0; i < defList->child_count; i++) {
            Node *def = defList->children[i];
            Type fieldType = getType(def->children[0]);
            Node *decList = def->children[1];
            for (int j = 0; j < decList->child_count; j++) {
                Node *dec = decList->children[j];
                char *fieldName = dec->children[0]->children[0]->value;
                if (findField(structType, fieldName)) {
                    semanticError(15, dec->children[0]->lineNo, "Redefined field");
                } else {
                    addField(structType, fieldName, fieldType);
                }
            }
        }
    }

    if (structName) {
        insertStruct(structName, structType);
        insertSymbol(createVariableSymbol(structName, structType, lineNo));
    }


    return structType;
}

Type checkStructVariable(Node *varDec, Type baseType) {
    if (!baseType) return NULL;
    if (baseType->kind == STRUCTURE && baseType->u.structure.name) {
        Type s = findStruct(baseType->u.structure.name);
        if (!s) {
            semanticError(17, varDec->lineNo, "Undefined structure");
            return NULL;
        } else {
            return s; // 返回符号表里真实类型
        }
    }
    return baseType;
}


